const config = {
  mailer: {
    service: 'Naver',
    user: 'hyunt0413@naver.com', // mail address
    pass: 'aoqhddur3ghtjs', // mail password
  },
};

module.exports = config;
